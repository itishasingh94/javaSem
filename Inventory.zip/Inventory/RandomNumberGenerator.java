/*****************************************************************************************************************
 * @description Main class responsible for facilitating connection between all the classes and proving necessary
 *              functionality needed for the project's implemetation.
 * @date        18-08-2018
 * @author      Itisha Singh
 * @version     version1.0
 ****************************************************************************************************************/

import java.util.Random;
public class RandomNumberGenerator
{
    private int minimumValue, maxiumumValue;
    
    /** ------------- DEFAULT CONSTRUCTOR -------------
     * @description Default constructor of class used to initialize fields and instantiate objects.
     * @author      Itisha Singh
    */
    public RandomNumberGenerator()
    {
        minimumValue = 0;
        maxiumumValue = 0;
    }
    
    /** ------------- DISPLAY CURRENT STATE OF AN OBJECT -------------
     * @description Default constructor of class used to initialize fields and instantiate objects.
     * @author      Itisha Singh
    */
    public void displayCurrentObject()
    {
        System.out.println("Minimum Value ="+ minimumValue);
        System.out.println("Maximum Value ="+ maxiumumValue);
    }
    
        /** * @description Update min value to the value of a variable.
          @parameters  minimumValue
          @returntype  void*/
    public void setMinimumValue(int minimumValue)
    { this.minimumValue = minimumValue; }
    
    /** * @description get value of minValue
     *    @parameters  none
     *    @returntype  int */
    public int getMinimumValue()
    { return minimumValue;}
    
        /** * @description Update max value to the value of a variable.
          @parameters  maxiumumValue
          @returntype  void*/
    public void setMAximumValue(int maxiumumValue)
    { this.maxiumumValue = maxiumumValue; }
    
    
    /** * @description get value of maxValue
     *    @parameters  none
     *    @returntype  int */
    public int getMaxiumumValue()
    { return maxiumumValue;}
    
    /** ------------- GENERATE RANDOM NUMBER -------------
     * @description this method generate a random number (integer) between the upper and lower given limits using a mathematical
     *              formulae and uses math.random() function to do so.
     * @parameters  minimumValue,maxiumumValue
     * @returntype  int
     * @author      Itisha Singh
     */
    public int generateRandomNumber(int minimumValue, int maxiumumValue)
    {
        int randomNumber = (maxiumumValue + (int)(Math.random() * ((minimumValue - maxiumumValue) + 1)));
        return randomNumber;
    }
}