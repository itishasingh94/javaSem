import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * @desc    ShipList    -  Intermediate class between ship and game. Holds the ArrayList of type Ship for both player and computer.
 * @version 1.0 ( 10.Oct.2018 )
 * @author  Itisha Singh
 * @fields  ships : ArrayList<Ship>
 */
public class ShipList
{
    private ArrayList<Ship> ships;

    /**
     * @desc    default constructor     - used to intansiate objects
     * @param   none
     * @return  none
     */
    public ShipList()
    {
        ships = new ArrayList<Ship>();
    }

    /**
     * @desc    addNewShip    - adds the ship details to the ship arraylist.
     * @param   shipNumber : int | shipName : String | xPos : int | yPos : int | hitsMade : int | hitsNeeded : int
     * @return  void
     */
    public void addNewShip(int shipNumber,String shipName,int xPos,int yPos, int hitsMade, int hitsNeeded)
    {
        ships.add(new Ship(shipName,xPos,yPos,hitsMade,hitsNeeded));
    }

   
    /**
     * @desc    displayGrid    - display grid for player and computer.
     * @param   shipNumber : int | shipName : String | xPos : int | yPos : int | hitsMade : int | hitsNeeded : int
     * @return  void
     */
    public void displayGrid(int gridSize, boolean shipVisible)
    {
        int i, j, num = 0;
        boolean shipFound; String x = "";
            StringBuffer str = new StringBuffer("");
        for(i = 1; i <= gridSize; i++)
        {
            for( j = 1; j <= gridSize; j++)
            {
                if(shipVisible == true)
                {
                    if(findShip(i,j) == true)
                    {
                        int index = getShipNumber(i,j);
                        if(ships.get(index).getNoOfHitsMade() == 0)
                                //x =" O ";
                               str.append(" O ");
                            else if(ships.get(index).getNoOfHitsMade() >=1 && ships.get(index).getNoOfHitsMade() != ships.get(index).getNoOfHitsNeeded())
                                //x = " D ";
                                str.append(" D ");

                            else if(ships.get(index).getNoOfHitsMade() == ships.get(index).getNoOfHitsNeeded())
                               // x =" X ";
                                str.append(" X ");
                    }
                    else
                       //  x = " ~ ";
                        str.append(" ~ ");
                         
                    System.out.print(str.toString());
                    
                }
                else
                {
                    System.out.print(" ~ ");
                }
            }
            System.out.println();
        }            
    }

    /**
     * @desc    findShip    - looks through the ship list to find if ship exits on the current grid
     * @param   xPos : int | yPos : int 
     * @return  boolean
     */
    public boolean findShip(int xPos, int yPos)
    {
        int num = 0;
        while(num < ships.size())
        {
            if(ships.get(num).getXPos()==xPos && ships.get(num).getYPos()==yPos)
            { return true; }
            num++;
        }
        return false;
    }
 
    /**
     * @desc    getShipNumber    - returns the ship numerb for a particular grid.
     * @param   i : int | j : int
     * @return  int
     */
    public int getShipNumber(int i, int j)
    {
        int num = 0, index = 0;
        while(num < ships.size())
        {
            if(ships.get(num).getXPos()==i && ships.get(num).getYPos()==j)
            { index = num; 
                break;
            }
            num++;
        }
        return index;
    }
    
    /**
     * @desc    getShips    - getter method for ships - returns values of shiplist
     * @param   none
     * @return  ArrayList<Ship>
     */
    public ArrayList<Ship> getShips()
    {
        return this.ships;
    }

    /**
     * @desc    hitShip    - to find out if ship got hit 
     *              returns 1   if shit gets hit,
     *              returns -1  if ship is already dead(i.e. no of hits made = no of hits needed)
     *              returns 0   if ship is not found
     * @param   xPos: int | yPos : int
     * @return  int
     */
    public int hitShip(int xPos, int yPos)
    {
        int isHit = 0, num = 0;
        while(num < ships.size())
        {
            if(ships.get(num).getXPos()==xPos && ships.get(num).getYPos()==yPos)
            {
                if(ships.get(num).getNoOfHitsMade() < ships.get(num).getNoOfHitsNeeded())
                {
                    ships.get(num).setNoOfHitsMade((ships.get(num).getNoOfHitsMade())+1);
                    isHit = 1;
                    break;
                }
                else if (ships.get(num).getNoOfHitsMade() == ships.get(num).getNoOfHitsNeeded())
                {
                    isHit = -1;
                    break;
                }
            }
            else
                isHit = 0;
            num++;
        }
        return isHit;
    }

    /**
     * @desc    noShipsAlive    - finds if any ships in the list are not dead i.e. this function determines the loser in the game, making the other play winner
     *                            returns true if no more ships are alive anymore.
     * @param   none
     * @return  boolean
     */
    public boolean noShipsAlive()
    {
        int deadShips = 0;
        for(int num = 0; num < ships.size(); num++)
        {
            if( ships.get(num).getNoOfHitsMade() == ships.get(num).getNoOfHitsNeeded() )
                deadShips++;
        } 

        if(deadShips == ships.size())
            return true;
        else
            return false;     
    }

    /**
     * @desc    setShips    - setter method for ships - updates value of shiplist
     * @param   ships : ArrayList<Ship>
     * @return  void
     */
    public void setShips(ArrayList<Ship> ships) 
    {
        this.ships = new ArrayList<>(ships);
    }

}
