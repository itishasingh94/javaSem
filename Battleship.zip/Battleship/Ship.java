
/**
 * 
 * @desc    Ship    -  stores all the attributes of a ship, has mutator and accessors of ship attributes
 * @version 1.0 ( 10.Oct.2018 )
 * @author  Itisha Singh
 * @fields  shipName : String | xPos : int | yPos : int | noOfHitsMade : int | noOfHitsNeeded : int
 */
public class Ship
{
    private String shipName;
    private int xPos;
    private int yPos;
    private int noOfHitsMade;
    private int noOfHitsNeeded;

    /**
     * @desc    default constructor     - used to intansiate objects and assign default values to fields
     * @param   none
     * @return  none
     */
    public Ship()
    {
        shipName = "";
        xPos = 0;
        yPos = 0;
        noOfHitsMade = 0;
        noOfHitsNeeded = 0;
    }
    
    /**
     * @desc    parameterized constructor     - to assign values to the current object
     * @param   shipName : String | xPos : int | yPos : int | noOfHitsMade : int | noOfHitsNeeded : int
     * @return  none
     */
    public Ship(String shipName,int xPos, int yPos,int noOfHitsMade, int noOfHitsNeeded)
    {
        this.shipName = shipName;
        this.xPos = xPos;
        this.yPos = yPos;
        this.noOfHitsMade = noOfHitsMade; 
        this.noOfHitsNeeded = noOfHitsNeeded;
    }

    /**
     * @desc    display     - displays the current state (current values assigned) of the object of the ship class 
     * @param   none
     * @return  void
     */  
    public void display()
    {
        System.out.println("Displaying current ship object status :");
        System.out.println("Ship name : " + this.shipName + "\n"+
                           "X position : " + this.xPos + "\n"+
                           "Y position : " + this.yPos + "\n"+
                           "number of hits made so far : " + this.noOfHitsMade + "\n"+
                           "number of hits needed to destroy the ship : " + this.noOfHitsNeeded + "\n");
    }
      
    /**
     * @desc    getNoOfHitsNeeded    - (accessor method) - retrives the value set in the noOfHitsNeeded attribute of ship
     * @param   none
     * @return  int
     */
    public int getNoOfHitsNeeded()
    { return this.noOfHitsNeeded; }
    
        /**
     * @desc    getNoOfHitsMade    - (accessor method) - retrives the value set in the noOfHitsMade attribute of ship
     * @param   none
     * @return  int
     */
    public int getNoOfHitsMade()
    { return this.noOfHitsMade; }


      /**
     * @desc    getShipName    - (accessor method) - retrives the value set in the shipName attribute of ship
     * @param   none
     * @return  String
     */
    public String getShipName()
    { return this.shipName; }

       /**
     * @desc    getXPos    - (accessor method) - retrives the value set in the xPos attribute of ship
     * @param   none
     * @return  int
     */
    public int getXPos()
    { return this.xPos; }
    
        /**
     * @desc    getYPos    - (accessor method) - retrives the value set in the yPos attribute of ship
     * @param   none
     * @return  int
     */
    public int getYPos()
    { return this.yPos; }
    
    /**
     * @desc    setNoOfHitsNeeded     - (mutator method) - sets value for number of hits needed i.e. hull strength of the ship from parameter to the object
     * @param   noOfHitsNeeded : int
     * @return  void
     */
    public void setNoOfHitsNeeded(int noOfHitsNeeded)
    { this.noOfHitsNeeded = noOfHitsNeeded; }
    
    /**
     * @desc    setNoOfHitsMade     - (mutator method) - sets value for number of hits made to the ship from parameter to the object
     * @param   noOfHitsMade : int
     * @return  void
     */
    public void setNoOfHitsMade(int noOfHitsMade)
    { this.noOfHitsMade = noOfHitsMade; }
  
    /**
     * @desc    setShipName     - (mutator method) - sets value of ship name from parameter to the object
     * @param   shipName : String
     * @return  void
     */
    public void setShipName(String shipName)
    { this.shipName = shipName; }

    /**
     * @desc    setXPos     - (mutator method) - sets value for x coordinate of the ship from parameter to the object
     * @param   xPos : int
     * @return  void
     */
    public void setXPos(int xPos)
    { this.xPos = xPos; }


    /**
     * @desc    setYPos     - (mutator method) - sets value for x coordinate of the ship from parameter to the object
     * @param   yPos : int
     * @return  void
     */
    public void setYPos(int yPos)
    { this.yPos = yPos; }

}
