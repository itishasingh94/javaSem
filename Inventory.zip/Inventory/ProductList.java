/*****************************************************************************************************************
 * @description Product List class contains accessor and mutator methods of listOfProducts. It has functionalities
 *              to add products to the cart, remove products from cart, viewing the cart,
 *              checks for the matching names in the cart.
 * @date        18-08-2018
 * @author      Itisha Singh
 * @version     version1.0
 ****************************************************************************************************************/
 import java.util.*;
public class ProductList
{
    private Product[] listOfProducts = new Product[5];

    /** ------------- DEFAULT CONSTRUCTOR -------------
     * @description Default constructor of class used to initialize fields and instantiate objects.
     * @author      Itisha Singh
    */
    public ProductList()
    {
        int count;
        for(count= 0; count< listOfProducts.length; count++)
        {  listOfProducts[count] = new Product(); }
    }

    /** * @description Update listOfProducts to the value of a variable.
          @parameters  listOfProducts
          @returntype  void*/
    public void setListOfProducts(Product[] listOfProducts)
    {
        this.listOfProducts = listOfProducts;
    }

    /** * @description get value of listOfProducts
     *    @parameters  none
     *    @returntype  Product[] */
     public Product[] getListOfProducts()
    {
        return listOfProducts;
    }

    /** ------------- REGISTER PRODUCTS -------------
     * @description this method add products to the inventory / updates values for listOfProducts.
     * @parameters  productName, productDesc, productPrice, productQty, productMinQty
     * @returntype  void
     * @author      Itisha Singh
    */
    protected void registerProduct(String productName, String productDesc, double productPrice, int productQty, int productMinQty)
    {  
        for(int count=0; count<listOfProducts.length; count++)
        {
            if(listOfProducts[count].getName() == "")
            {
                listOfProducts[count].setName(productName);
                listOfProducts[count].setDesc(productDesc);
                listOfProducts[count].setPrice(productPrice);
                listOfProducts[count].setQtyOnHand(productQty);
                listOfProducts[count].setMinOrderQty(productMinQty);
                System.out.println("Product " + (count+1) +" Successfully Registered!");
                setListOfProducts(listOfProducts);
                break;
            }
        }
    }
    
  /** ------------- VIEW PRODUCTS -------------
     * @description display all the products currently in the inventory
     * @parameters  itemNum
     * @returntype  void
     * @author      Itisha Singh
    */
    protected void viewProducts(int itemNum)
    {
        int count;  
        for(count= 0; count< itemNum; count++)
        {
            System.out.println("Select Product : " + (count+1));
            System.out.println("   Name = " + listOfProducts[count].getName());
            System.out.println("   Desc = " + listOfProducts[count].getDesc());
            System.out.println("   Price = " + listOfProducts[count].getPrice());
            System.out.println("   Quantity at Hand = " + listOfProducts[count].getQtyOnHand());
            System.out.println("   Minimum OrderQuantity = " + listOfProducts[count].getMinOrderQty()+"\n");
        }
    }
    
    /** ------------- CHECK FOR EXISTING PRODUCT NAME -------------
     * @description this method checks for a match for exisiting name of the product previosuly entered in the inventory.
     *              returns true if a match is found else returns false.
     * @parameters  name
     * @returntype  boolean
     * @author      Itisha Singh
    */
    protected boolean checkForProductName(String name)
    {
        int count;
        for(count= 0; count <listOfProducts.length; count++)
        {
            while(name.equalsIgnoreCase(listOfProducts[count].getName()))
            {
                return true;
            }
        }
        return false;
    }
     
    /** ------------- CHECK LENGTH OF THE PRODUCT NAME-------------
     * @description this method checks if the length of the name of the product is between 3 to 25
     *              returns true if length of name is between defined lines else returns false.
     * @parameters  name
     * @returntype  boolean
     * @author      Itisha Singh
    */
    
    protected boolean checkProductLength (int length )
    {
        if(length >=3 && length < 25)
            return true;
        else
            return false;    
    }
}