
import java.util.*; 
import java.io.*;
import java.io.File;
import java.io.IOException;

/**
 * 
 * @desc    Game    -  It interacts with the users to take inputs and play the game
 * @version 1.0 ( 10.Oct.2018 )
 * @author  Itisha Singh
 * @fields  playerShips : ShipList, computerShips : ShipList
 */
public class Game
{
    private ShipList playerShips, computerShips;   

    /**
     * @desc    default constructor     - used to intansiate objects
     * @param   none
     * @return  none
     */
    public Game()
    {
        playerShips = new ShipList();
        computerShips = new ShipList();
    }


    /**
     * @desc    diplayComputerGrid  - calls shipList method to display computer grid 
     * @param   gridSize : int
     * @return  void
     */
    public void diplayComputerGrid(int gridSize, boolean shipVisible)
    {
        System.out.println("\n Displaying the Computer Grid !");
        if(shipVisible)
            computerShips.displayGrid(gridSize,true);
        else
            computerShips.displayGrid(gridSize,false);
    }
    
    
    /**
     * @desc    displayPlayerGrid  - calls shipList method to display player grid 
     * @param   gridSize : int
     * @return  void
     */
    public void displayPlayerGrid(int gridSize)
    {
        System.out.println("\n Displaying the Player Grid !");
        playerShips.displayGrid(gridSize,true);
    }

    
        /**
     * @desc    gameController  - main menthod that displays the header and file setting(after reading them from FileIO class.
     *                            calls all other methods of the class.
     * @param   none
     * @return  void
     */
    public void gameController()
    {
        System.out.print('\u000C');
        System.out.println("+=======================================================================================+");
        System.out.println("|                                                                                       |");
        System.out.println("|                      WELCOME TO THE BATTLESHIP GAME -- WITH A TWIST !!                |");
        System.out.println("|                                                                                       |");
        System.out.println("+=======================================================================================+");

        /** reading settings from file */
        FileIO file = new FileIO();
        String[] setting  = file.readFile();
        int gridSize = Integer.parseInt(setting[0]);
        boolean multiHits = Boolean.valueOf(setting[1]);
        boolean shipVisible = Boolean.valueOf(setting[2]);
        int maxShips = Integer.parseInt(setting[3]);

        /** display settings */
        System.out.println("The game will use the grid size defined in the settings file.");
        System.out.println("Playing Grid size set as ("+ gridSize +"x"+ gridSize +")");
        System.out.println("Maximum number of ships allowed as "+ maxShips);
        System.out.println("Multiple hits allowed per ships set as "+ multiHits);
        System.out.println("Computer ships visible : "+ shipVisible + "\n");

        loadPlayerSettings(maxShips, gridSize,multiHits);
        displayPlayerGrid(gridSize);
        loadComputerSettings(maxShips,gridSize, multiHits);
        diplayComputerGrid(gridSize,shipVisible);
        startGame(maxShips, gridSize,shipVisible, file);
    }


    /**
     * @desc    loadComputerSettings  - randomly generates computer ships' coordinates. 
     * @param   maxShips : int | gridSize : int | multiHits : boolean
     * @return  void
     */
    public void loadComputerSettings(int maxShips, int gridSize, boolean multiHits)
    {
        Validation valid = new Validation();
        CoordinateGenerator generator = new CoordinateGenerator();

        String shipName = "";
        int xCoord, yCoord, hitsMade=0, hitsNeeded;
        boolean validInput = false;
        System.out.println("Loading Computer Settings : ");
        for(int i = 0; i <maxShips; i++)
        {
            shipName = "Ship "+(i+1);
            boolean gridTaken = true;
            do
            {
                xCoord = generator.generateCoordinates(1,gridSize);
                yCoord  = generator.generateCoordinates(1,gridSize);
                if(multiHits)
                    hitsNeeded = generator.generateHullStrength(1,5);
                else
                    hitsNeeded = 1;

                gridTaken = computerShips.findShip(xCoord, yCoord);
                if(!gridTaken)
                    computerShips.addNewShip(i, shipName, xCoord, yCoord, hitsMade, hitsNeeded);

            } while(gridTaken);
        }
        System.out.println("Computer Settings Loaded..!");
    }

    /**
     * @desc    loadPlayerSettings  - prompts user to input values (via Input class) validates them (via Validation Class) 
     * @param   maxShips : int |  gridSize : int | multiHits : boolean
     * @return  void
     */
    public void loadPlayerSettings(int maxShips, int gridSize, boolean multiHits)
    {
        Input input = new Input();
        Validation valid = new Validation();
        String shipName, xPos = "", yPos = "";
        int hitsMade=0, hitsNeeded=0;
        boolean validInput, numberCheck = false, gridTaken ;
        CoordinateGenerator generator = new CoordinateGenerator();

        System.out.println("Loading Player Settings : ");
        for(int i = 0; i <maxShips; i++)
        {
            System.out.println("Please enter details for the ship "+ (i+1) +": ");

            System.out.println("Ship Name:");
            shipName = input.getShipName();
            validInput = valid.validateShipName(shipName);
            while(!validInput)
            {
                shipName = input.getShipName();
                validInput = valid.validateShipName(shipName);
            }

            gridTaken = true;
            do
            {
                System.out.println("Ship x Postion (1 - "+ gridSize +") :");
                xPos = input.getCoordinate();
                validInput = valid.validateCoordinate(xPos,gridSize);
                while(!validInput)
                {
                    xPos = input.getCoordinate();
                    validInput = valid.validateCoordinate(xPos,gridSize);
                }

                System.out.println("Ship y Postion (1 - "+ gridSize +") :");
                yPos = input.getCoordinate();
                validInput = valid.validateCoordinate(yPos,gridSize);
                while(!validInput)
                {
                    yPos = input.getCoordinate();
                    validInput = valid.validateCoordinate(yPos,gridSize);
                }

                if(multiHits)
                    hitsNeeded = generator.generateHullStrength(1,5);
                else
                    hitsNeeded = 1;

                gridTaken = playerShips.findShip(Integer.parseInt(xPos), Integer.parseInt(yPos));
                if(gridTaken)
                    System.out.println(" A ship is already on this grid! enter different coordinates.!");
                else
                    playerShips.addNewShip(i, shipName, Integer.parseInt(xPos), Integer.parseInt(yPos), hitsMade, hitsNeeded);
            } while(gridTaken);

        }
        System.out.println("Player Settings Loaded..!\n");
    }

    /**
     * @desc    startGame  - The method plays the actual game
     * @param   maxShips : int| gridSize : int | shipVisible : boolean | file : FileIO
     * @return  void
     */
    public void startGame(int maxShips, int gridSize, boolean shipVisible, FileIO file)
    {
        int round = 1, playerScore = 0, isHit= 0, compScore = 0;
        String xPos,yPos;
        boolean validInput, gameOver = false;
        Validation valid = new Validation();
        Input input = new Input();
        CoordinateGenerator generator = new CoordinateGenerator();
        input.pressKey();

        do
        {
            System.out.print('\u000C');

            System.out.println("Round : " + round + "\n");
            System.out.println("Player Score :" + playerScore);
            System.out.println("Computer Score :" + compScore);
            System.out.println("\n Player to make a guess...");

            System.out.println("Ship x Postion (1 - "+ gridSize +") :");
            xPos = input.getCoordinate();
            validInput = valid.validateCoordinate(xPos,gridSize);
            while(!validInput)
            {
                xPos = input.getCoordinate();
                validInput = valid.validateCoordinate(xPos,gridSize);
            }

            System.out.println("Ship y Postion (1 - "+ gridSize +") :");
            yPos = input.getCoordinate();
            validInput = valid.validateCoordinate(yPos,gridSize);
            while(!validInput)
            {
                yPos = input.getCoordinate();
                validInput = valid.validateCoordinate(yPos,gridSize);
            }

            isHit = computerShips.hitShip(Integer.parseInt(xPos), Integer.parseInt(yPos));
            if(isHit == 0)
                System.out.println("Player MISSED..!");
            else if(isHit == 1)
            {
                System.out.println(" * * * CONGRATS PLAYER...! You hit a Computer Ship!!! * * * \n");
                playerScore = playerScore + 10;
            }
            else if(isHit == -1)
                System.out.println("\n - - - - - - - Ship Already Destroyed..! Turn Wasted.");

            System.out.println("\nComputer to make a guess...");
            int xCoord = generator.generateCoordinates(1,gridSize);         //check id min should be zero only or 1. baad me dekh lena ek baar. 
            int yCoord = generator.generateCoordinates(1,gridSize);
            System.out.println("Computer Guessed (x,y) = (" + xCoord + "," + yCoord + ")");

            isHit = playerShips.hitShip(xCoord,yCoord);
            if(isHit == 0)
                System.out.println("Computer MISSED..!");
            else if(isHit == 1)
            {
                System.out.println(" * * * CONGRATS COMPUTER...! You hit a Player Ship!!! * * * \n");
                compScore = compScore + 10;
            }
            else if(isHit == -1)
                System.out.println("\n - - - - - - - Ship Already Destroyed..!Turn Wasted.");

            round++;
            displayPlayerGrid(gridSize);
            diplayComputerGrid(gridSize, shipVisible);
            input.pressKey();

            if(playerShips.noShipsAlive() == true || computerShips.noShipsAlive() == true)
            { 
                gameOver = true;
                if(playerShips.noShipsAlive() == true)
                {   
                    System.out.println("\nComputer Won. . . . Player Scores = " + playerScore + " | Computer Score = " + compScore);
                    file.writeGameOutput(playerScore, compScore, " . Computer Won!");
                }
                else if(computerShips.noShipsAlive() == true)
                {
                    System.out.println("\nPlayer Won. . . . Computer Scores = " + compScore + " | Player Score = " + playerScore);
                    file.writeGameOutput(playerScore, compScore,  " . Player Won!");
                }
            }
            else
                gameOver = false;

        }while(gameOver == false);
    }
}