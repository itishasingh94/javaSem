
import java.io.File; 
import java.io.*;
import java.io.FileNotFoundException; 
import java.util.Scanner; 

/**
 * 
 * @desc    FileIO    -  Read settings file to load game settings and writes output to the gameOutput file.
 * @version 1.0 ( 10.Oct.2018 )
 * @author  Itisha Singh
 * @fields  fileName : String
 */
public class FileIO
{ 
    private String fileName;

    /**
     * @desc    default constructor     - used to intansiate objects
     * @param   none
     * @return  none
     */
    public FileIO()
    {
        fileName = "gameSettings.txt";
    }

    /**
     * @desc    readFile    - reads values from a text file and save them in a string array which loads settings of the game
     * @param   none
     * @return  String[]
     */
    public String[] readFile()
    { 
        String[] values = new String[4];
        try
        {
            BufferedReader in = new BufferedReader(new FileReader(fileName));
            String str;
            for(int i=0; i<4;i++)
                values[i] = new String();

            while ((str = in.readLine())!= null)
            {    values = str.split(",");   }
            in.close();
        }
        catch (FileNotFoundException e1) 
        {
            System.out.println("\n 'gamesetting.txt' File is not found...! Can't run the program without the settings file.");
        }
        catch (Exception e2) 
        {
            System.out.println("\n Error Encountered! System can't proceed..!");
        }
        return values;
    } 

    /**
     * @desc    writeGameOutput    - writing the output 'winner' of the game in the gameOutput.txt file.
     * @param   playerScore : int | compScore : int | winner : String
     * @return  String[]
     */
    public void writeGameOutput(int playerScore,int compScore, String winner) 
    {
        String file = "gameOutput.txt";
        String displayMessage = winner + " Player Score = " + playerScore + " And computer score = " + compScore;
        try
        {
            PrintWriter outputFile = new PrintWriter(file);
            outputFile.println(displayMessage);
            outputFile.close();
        }
        catch(IOException e)
        {
            System.out.println("\n Error Encountered! Can't access the file."); 
        }
    }

}

