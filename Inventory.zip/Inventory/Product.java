/*****************************************************************************************************************
 * @description Main class responsible for facilitating connection between all the classes and proving necessary
 *              functionality needed for the project's implemetation.
 * @date        18-08-2018
 * @author      Itisha Singh
 * @version     version1.0
 ****************************************************************************************************************/
public class Product
{
    private String name;
    private String desc;
    private double price;
    private int qtyOnHand;
    private int minOrderQty;
    
    /** ------------- DEFAULT CONSTRUCTOR -------------
     * @description Default constructor of class used to initialize fields and instantiate objects.
     * @author      Itisha Singh
    */
    public Product()
    {
       name = "";
       desc = "";
       price = 0.0;
       qtyOnHand = 0;
       minOrderQty = 0;
    }
      
    /** * @description Update name to the value of a variable.
          @parameters  name
          @returntype  void*/
    public void setName(String name)
    { this.name = name; }

    
    /** * @description get value of name
     *    @parameters  none
     *    @returntype  String */
    public String getName()
    { return name; }
    
    /** * @description Update description to the value of a variable.
          @parameters  desc
          @returntype  void*/     
    public void setDesc(String desc)
    { this.desc = desc; }

    /** * @description get value of description
     *    @parameters  none
     *    @returntype  String */
    public String getDesc()
    { return desc; }
    
         /** * @description Update price to the value of a variable.
          @parameters  price
          @returntype  void*/
    public void setPrice(double price)
    { this.price = price; }

    /** * @description get value of price
     *    @parameters  none
     *    @returntype  double */
    public double getPrice()
    { return price; }
    
        /** * @description Update quantity on hand to the value of a variable.
          @parameters  QtyOnHand
          @returntype  void*/
    public void setQtyOnHand(int qtyOnHand)
    { this.qtyOnHand = qtyOnHand; }
    
    /** * @description get value of quantity on hand
     *    @parameters  none
     *    @returntype  int */
    public int getQtyOnHand()
    { return qtyOnHand; }
    
        /** * @description Update minimum Order Quantity to the value of a variable.
          @parameters  minOrderQty
          @returntype  void*/
    public void setMinOrderQty(int minOrderQty)
    { this.minOrderQty = minOrderQty; }
    
    /** * @description get value of minimum order quantity
     *    @parameters  none
     *    @returntype  int */
    public int getMinOrderQty()
    { return minOrderQty; }
}