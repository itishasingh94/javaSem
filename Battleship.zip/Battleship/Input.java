import java.util.Scanner;
import java.io.*;

/**
 * 
 * @desc    Input    -  takes input from console (user input)
 * @version 1.0 ( 10.Oct.2018 )
 * @author  Itisha Singh
 * @fields  none
 */
public class Input
{   
    
    /**
     * @desc    getCoordinate   - prompts user for input a coordinate values in String format, returns it to game class
     * @param   none
     * @return  String
     */
    public String getCoordinate()
    {
        Scanner scan = new Scanner(System.in);
        String coordinate = scan.nextLine();
        return coordinate;
    }
    
    /**
     * @desc    getShipName     - prompts user for input a ship name, returns it to game class
     * @param   none
     * @return  String
     */
    public String getShipName()
    {
       Scanner scan = new Scanner(System.in);
       String shipName = scan.nextLine();
       return shipName;
    }
    
    /**
     * @desc    pressKey    - prompts user to press any key to proceed with the game
     * @param   none
     * @return  void
     */
    public void pressKey()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Press any key to continue...");
        String input = scan.nextLine();
    }
}
