import java.util.Random;

/**
 * 
 * @desc    CoordinateGenerator    -  used to generate a random number between the min and max values
 * @version 1.0 ( 10.Oct.2018 )
 * @author  Itisha Singh
 * @fields  minimumValue int | maxiumumValue int
 */
public class CoordinateGenerator
{
    private int minimumValue, maxiumumValue;

    /**
     * @desc    default constructor     - used to intansiate objects and assign default values to fields
     * @param   none
     * @return  none
     */
    public CoordinateGenerator()
    {
        minimumValue = 0;
        maxiumumValue = 0;
    }

    /**
     * @desc    parameterized constructor     - to assign values to the current object
     * @param   none
     * @return  none
     */
    public CoordinateGenerator(int minimumValue, int maxiumumValue)
    {
        this.minimumValue = minimumValue;
        this.maxiumumValue = maxiumumValue;
    }

    /**
     * @desc    display     - displays the current state (current values assigned) of the object of the ship class 
     * @param   none
     * @return  void
     */ 
    public void displayCurrentObject()
    {
        System.out.println("Minimum Value ="+ minimumValue);
        System.out.println("Maximum Value ="+ maxiumumValue);
    }

    /**
     * @desc    generateCoordinates    - generates a random number between the minimum and the maximum range inclusive of both
     *                                 - returns a value which is the coordinate of the computer ship
     * @param   minimumValue : int | maxiumumValue : int
     * @return  int
     */
    public int generateCoordinates(int minimumValue, int maxiumumValue)
    {
        int coordinate = (maxiumumValue + (int)(Math.random() * ((minimumValue - maxiumumValue) + 1)));
        return coordinate;
    }

    /**
     * @desc    generateHullStrength    - generates a random number between the minimum and the maximum range inclusive of both
     *                                  - returns a value which is the hull strength of the ship i.e. number of hits that will be needed to destroy the ship
     * @param   minimumValue : int | maxiumumValue : int
     * @return  int
     */
    public int generateHullStrength(int minimumValue, int maxiumumValue)
    {
        int strength = (maxiumumValue + (int)(Math.random() * ((minimumValue - maxiumumValue) + 1)));
        return strength;
    }

    /**
     * @desc    getMaxiumumValue    - (accessor method) - retrives the value set in the maxiumumValue attribute of ship
     * @param   none
     * @return  int
     */
    public int getMaxiumumValue()
    { return maxiumumValue;}

    /**
     * @desc    getMinimumValue    - (accessor method) - retrives the value set in the minimumValue attribute of ship
     * @param   none
     * @return  int
     */
    public int getMinimumValue()
    { return minimumValue;}

    /**
     * @desc    setMaximumValue     - (mutator method) - sets value for maximum from parameter to the object
     * @param   maximumValue : int
     * @return  void
     */
    public void setMaximumValue(int maxiumumValue)
    { this.maxiumumValue = maxiumumValue; }

    /**
     * @desc    setMinimumValue     - (mutator method) - sets value for minimum from parameter to the object
     * @param   minimumValue : int
     * @return  void
     */
    public void setMinimumValue(int minimumValue)
    { this.minimumValue = minimumValue; }

}
