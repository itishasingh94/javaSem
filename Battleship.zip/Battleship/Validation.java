import java.io.*;

/**
 * 
 * @desc    Validation    -  validates all user inputs to ensure all inputs are correct
 * @version 1.0 ( 10.Oct.2018 )
 * @author  Itisha Singh
 * @fields  none
 */
public class Validation
{

    /**
     * @desc    default constructor of validation class
     * @param   none
     * @return  none
     */
    public Validation()
    {}

    /**
     * @desc    isNumber    - checks if the entered value is a number of not
     * @param   input : String
     * @return  boolean
     */
    public boolean isNumber(String input)
    {
        try
        {   
            Integer.parseInt(input);    
        }
        catch(NumberFormatException e)
        {   
            return false;  
        }
        return true;
    }

    /**
     * @desc    validateCoordinate    - checks if the entered coordinate is in the range of 1 to gridSize
     * @param   coordinate : String | gridSize : int
     * @return  boolean
     */
    public boolean validateCoordinate(String coordinate,int gridSize)
    {
        if(isNumber(coordinate))
        {
            int pos = Integer.parseInt(coordinate);
            if(pos <= gridSize && pos > 0)
                return true;
            else
            {
                System.out.println("Enter coordinate in range : 1 to "+ gridSize +" :");
                return false;    
            }
        }
        else
        {
            System.out.println("Coordinates can only be numeric!");
            return false;
        }
    }

    /**
     * @desc    validateShipName    - checks if the entered shipName is within the defined range of 3 to 25
     * @param   shipName : String
     * @return  boolean
     */
    public boolean validateShipName(String shipName)
    {
        if(shipName.length() >= 3 && shipName.length() <=15)
            return true;
        else
        { 
            System.out.println("Enter valid ship name(Hint: btw 3 to 15)");
            return false;
        }
    }

}
