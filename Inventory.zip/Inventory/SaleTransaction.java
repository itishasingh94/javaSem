/*****************************************************************************************************************
 * @description Sale Transaction class contains accessor and mutator methods of saleCode, items and totalCost
 *              it has functionalities to add products to the cart, remove products from cart, viewing the cart,
 *              checks for the matching names in the cart.
 * @date        18-08-2018
 * @author      Itisha Singh
 * @version     version1.0
 ****************************************************************************************************************/

import java.util.*;
public class SaleTransaction
{
    private int saleCode;
    private Product[] items;
    private double totalCost;

    /** ------------- DEFAULT CONSTRUCTOR -------------
     * @description Default constructor of class used to initialize fields and instantiate objects.
     * @author      Itisha Singh
     */
    public SaleTransaction()
    {
        saleCode = 0;
        items = new Product[3];
        totalCost  = 0.0;

        for(int i =0; i<items.length; i++)
            items[i] = new Product();
    }

    /** * @description update saleCode to the value of a variable.
          @parameters saleCode
          @returntype void
          */
    public void setSaleCode(int saleCode)
    {
        this.saleCode = saleCode;
    }

    /** * @description get value of saleCode
          @parameters none
          @returntype int
          */
    public int getSaleCode()
    {
        return saleCode;
    }

    /** * @description update totalCost to the value of a variable.
          @parameters totalCost
          @returntype void
          */
    public void setTotalCost(double totalCost)
    {
        this.totalCost = totalCost;
    }

    /** * @description get value of totalCost.
          @parameters none
          @returntype double*/
    public double getTotalCost()
    {
        return totalCost;
    }

    /** * @description update setItems to the value of a variable.
          @parameters items
          @returntype void*/
    public void setItems(Product[] items)
    {
        this.items = items;
    }

    /** * @description get value of getItems 
          @parameters none
          @returntype Product[]*/
    public Product[] getItems()
    {
        return items;
    }

    /** ------------- ADD TO CART -------------
     * @description this method adds selected product to the cart (item list)
     * @parameters  name, desc, price, qtyOnHand, minQty
     * @returntype  void
     * @author      Itisha Singh
     */
    protected void addToCart(String name, String desc, double price, int qtyOnHand,int minQty)
    {
        for(int count=0; count<items.length; count++)
        {
            if(items[count].getName() == "")
            {
                items[count].setName(name);
                items[count].setDesc(desc);
                items[count].setPrice(price);
                items[count].setQtyOnHand(qtyOnHand);
                items[count].setMinOrderQty(minQty);
                System.out.println("Product " + (count+1) +" Successfully Added to Cart!");
                setItems(items);
                break;
            }
        }
    }

    /** ------------- VIEW CART -------------
     * @description this method views products in the cart
     * @parameters  inCart
     * @returntype  void
     * @author      Itisha Singh
     */
    protected void viewCart(int inCart)
    {
        int count;
        for(count = 0; count < inCart; count++)
        {
            System.out.println("Product : "+ (count+1)); 
            System.out.println("Name : "+ items[count].getName());
            System.out.println("Desc : "+ items[count].getDesc());
            System.out.println("Price : "+ items[count].getPrice());
            System.out.println("Quantity on Hand : "+ items[count].getQtyOnHand());
            System.out.println("Minimum Order Quantity : "+ items[count].getMinOrderQty()+"\n");
        }
    }

    /** ------------- REMOVE FROM THE CART -------------
     * @description this method removes products from the cart.
     * @parameters  productNumber
     * @returntype  void
     * @author      Itisha Singh
     */
    public void removeFromCart(int productNumber, int inCart)
    {
        int i,count = 0;
        boolean flag = true;

        for(count = 0; count < inCart; count++)
        {
            if(productNumber == inCart-1)
                 items[productNumber] = null;
            else
            {
                 items[productNumber] =  items[productNumber+1];
                 items[productNumber+1] = null;
            }
        }
        System.out.println("Product Removed!");
    }

    /** ------------- CHECK FOR MATCH -------------
     * @description this method checks for the match of exisiting product in cart by comparing names.
     * @parameters  name
     * @returntype  boolean
     * @author      Itisha Singh
     */
    public boolean checkForMatch(String name)
    {
        int count;
        for(count = 0; count < items.length; count++)
        {
            while(name.equalsIgnoreCase(items[count].getName()))
            {
                return false;
            }
        }
        return true;
    }

}