/*****************************************************************************************************************
 * @description Main class responsible for facilitating connection between all the classes and proving necessary
 *              functionality needed for the project's implemetation.
 * @date        18-08-2018
 * @author      Itisha Singh
 * @version     version1.0
 ****************************************************************************************************************/

import java.util.*;
public class Sale
{
    private ProductList prodList;
    private SaleTransaction transaction;

    /** ------------- DEFAULT CONSTRUCTOR -------------
     * @description Default constructor of class used to initialize fields and instantiate objects.
     * @author      Itisha Singh
     */
    public Sale()
    {
        prodList = new ProductList();
        transaction = new SaleTransaction();
    }

    /** ------------- INVENTORY -------------
     * @description this method clears console before the program begins and displays header.
     * @parameters  none
     * @returntype  void
     * @author      Itisha Singh
     */
    public void inventory()
    {
        System.out.print('\u000C');
        System.out.println("=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
        System.out.println("Welcome to the Simple Inventory Management System");
        System.out.println("=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
        homeController();
    }

    /** ------------- DISPLAY -------------
     * @description this method displays the menu to the user everytime a choice has to be made from available options
     * @parameters  null
     * @returntype  void
     * @author      Itisha Singh
     */
    private void display()
    {
        System.out.println("\nPlease Select from the following MENU options:");
        System.out.println("Press 1 to Register a Product for Sale");
        System.out.println("Press 2 to Buy a Product to the Cart");
        System.out.println("Press 3 to Remove a Product from the Cart");
        System.out.println("Press 4 to View all Available Products");
        System.out.println("Press 5 to Check out");
        System.out.println("Press 6 to Get Help");
        System.out.println("Press 7 to Exit\n");
        System.out.print("Please Enter your Choice: ");
    }

    /** ------------- HOME CONTROLLER -------------
     * @description this is the main menthod. Execution of the program is controlled by this menthod. It uses choice 
     *              of user for decision making and calls all the other methods of other classes by using object inheritance.
     * @parameters  null
     * @returntype  void
     * @author      Itisha Singh
     */    
    private void homeController()
    {
        int choice=0, inCart=0, noOfItems=0;
        Scanner scan = new Scanner(System.in);
        display();
        while(!scan.hasNextInt())
        {     
            System.out.println("Invalid Input! Enter numeric value!");
            scan.next();
        }
        choice = scan.nextInt();
        RandomNumberGenerator rand = new RandomNumberGenerator();
        boolean flag1 = true, flag2;
        while(flag1)
        {
            switch(choice)
            {
                ///** TO REGISTER PRODCUCTS IN THE INVENTORY*/
                case 1:  
                noOfItems = registerProducts(rand, noOfItems);
                display();
                while(!scan.hasNextInt())
                {     
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                choice = scan.nextInt();
                break;

                ///** TO DISPLAY AND ADD AVAIABLE PRODUCTS IN THE SHOPPING CART*/
                case 2:
                System.out.println(noOfItems);
                if(noOfItems == 0)
                    System.out.println("Sorry! Empty Inventory. Please Enter Products in Inventory first.");
                else
                    inCart = addProductsToCart(rand, noOfItems,inCart);
                display();
                while(!scan.hasNextInt())
                {     
                    System.out.print("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                choice = scan.nextInt();
                break;

                /**REMOVE PRODUCTS THAT ARE ADDED TO THE SHOPPING CART*/
                case 3:
                if(inCart == 0)
                    System.out.println("Sorry! Empty Cart. Please Add in cart first.\n");
                else
                    inCart = removeProductsFromCart(inCart);
                display();
                while(!scan.hasNextInt())
                {     
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                choice = scan.nextInt();
                break;

                /**VIEW PRODUCTS IN THE INVENTORY*/
                case 4:
                if(noOfItems == 0)
                    System.out.println("Sorry! Empty Inventory. Please Enter Products in Inventory first.\n");
                else
                {   
                    System.out.println("Currently Your Inventory Has Following Products");
                    prodList.viewProducts(noOfItems);
                }
                display();
                while(!scan.hasNextInt())
                {     
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                choice = scan.nextInt();
                break;

                /** CHECK OUT FROM THE CART */
                case 5:
                if(inCart == 0)
                    System.out.println("Sorry! Empty Cart. Please Add in cart first.\n");
                else
                    checkoutCart(inCart, noOfItems, rand);
                display();
                while(!scan.hasNextInt())
                {     
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                choice = scan.nextInt();
                break;

                /** HELP THE INVENTORY */
                case 6:
                helpUser();
                display();
                while(!scan.hasNextInt())
                {     
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                choice = scan.nextInt();
                break;

                /** SYSTEM EXIT */
                case 7:
                System.out.println("You Chose to Exit..! Thank You For Using Inventory Management System!");
                flag1 = false;
                System.exit(0);
                break;

                default:
                System.out.println("Enter a valid choice!");
                while(!scan.hasNextInt())
                {     
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                choice = scan.nextInt();
                break;

            }
        }
    }

    /** ------------- REGISTER PRODUCTS -------------
     * @description this method asks user to input values for the product and then calls method from class productList to 
     *              save the values to the inventory.
     * @parameters  rand, inventoryeLength
     * @returntype  int
     * @author      Itisha Singh
     */
    private int registerProducts(RandomNumberGenerator rand, int inventoryLength)
    {
        Scanner scan = new Scanner(System.in);
        int count;
        String productName = new String();
        String productDesc = new String();
        double productPrice = 0.0;
        int productQty = 0, productMinQty = 0;
        boolean flag = true, check = true, validName, checkLength;
        char nextInput;

        while(flag)
        { 
            if(inventoryLength == 5)
            {  System.out.println("Inventory is full.!");
                return inventoryLength;
            }

            System.out.print("Enter YES to add a product to inventory or NO to exit. : ");
            nextInput = scan.next().charAt(0);
            if(nextInput=='Y' || nextInput=='y')
            {
                System.out.println("Enter name :");
                productName = scan.next();
                validName = prodList.checkForProductName(productName);
                checkLength = prodList.checkProductLength(productName.length());

                while(validName || !checkLength)
                {
                    System.out.println("Your product is either beyond allowed length(3 to 25) or already exists. Try Again!");
                    productName = scan.next();
                    validName = prodList.checkForProductName(productName); 
                    checkLength = prodList.checkProductLength(productName.length());
                }

                System.out.print("Enter Description :");
                productDesc = scan.next();
                while(productDesc.length() <=1 && productDesc.length() >50)
                {
                    System.out.println("Enter a valid desc (Hint: Bwt 1 to 50 char only!)"); 
                    productDesc = scan.next();
                }

                System.out.println("Enter Price :");
                while(!scan.hasNextDouble())
                {
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                productPrice = scan.nextDouble();
                while(productPrice<=0)
                {
                    System.out.println("Price cannot be zero or less.");
                    productPrice = scan.nextDouble();
                }

                productQty = rand.generateRandomNumber(0,10);
                productMinQty = rand.generateRandomNumber(0,5);

                prodList.registerProduct(productName, productDesc, productPrice, productQty, productMinQty); 
                inventoryLength = inventoryLength+1;
            }
            else if(nextInput=='N'|| nextInput=='n')
                flag = false;
            else
                System.out.print("Enter a valid choice! ");
        }
        return inventoryLength;
    }

    /** ------------- ADD PRODUCTS TO THE CART-------------
     * @description this method add products from the inventory to the cart by calling the method form saleTransaction class
     *              to add products in the items array(cart)
     * @parameters  rand, noOfItems, inCart
     * @returntype  int
     * @author      Itisha Singh
     */
    private int addProductsToCart(RandomNumberGenerator rand, int noOfItems, int inCart)
    { 
        int productNumber= 0;
        int saleCode= 0;
        boolean flag;
        String name =" ",desc=" ";
        double price= 0.0;
        int qtyOnHand= 0, minQty= 0;
        Scanner scan  = new Scanner(System.in);
        System.out.println("Please select from the following products to add to the cart: ");
        prodList.viewProducts(noOfItems);
        flag= true;
        while(flag)
        { 
            if(inCart == 3)
            {
                System.out.println("Your Cart is full.!");
                transaction.setTotalCost(calulateTotalPrice(transaction, inCart));
                System.out.println("Current Total Price of Cart : " + transaction.getTotalCost());
                return inCart;
            }
            System.out.println("Enter YES to enter a product or NO to exit. : ");
            char nextInput = scan.next().charAt(0);
            if(nextInput=='Y' || nextInput=='y')
            {
                System.out.println("Enter Product Number: ");
                while(!scan.hasNextInt())
                {
                    System.out.println("Invalid Input! Enter numeric value!");
                    scan.next();
                }
                productNumber = scan.nextInt();
                while(productNumber > noOfItems || productNumber <=0)
                {    
                    System.out.println("Enter a valid product number!");
                    while(!scan.hasNextInt())
                    {
                        System.out.println("Invalid Input! Enter numeric value!");
                        scan.next();
                    }
                    productNumber = scan.nextInt();
                }

                name =  prodList.getListOfProducts()[productNumber-1].getName();
                desc = prodList.getListOfProducts()[productNumber-1].getDesc();
                price = prodList.getListOfProducts()[productNumber-1].getPrice();
                qtyOnHand = prodList.getListOfProducts()[productNumber-1].getQtyOnHand();
                minQty = prodList.getListOfProducts()[productNumber-1].getMinOrderQty();
                boolean match = transaction.checkForMatch(name); // if it doesnt find a match it returns true. if it finds one : returns false..!
                if(match)
                    {
                        if(minQty < qtyOnHand)
                        {  
                            transaction.addToCart(name, desc, price, qtyOnHand, minQty);
                            inCart = inCart+1;
                        }
                        else
                            System.out.println("Sorry! Minimum Order Quantity is less than Quantity On Hand. You can't order this product. Try another.");
                    }
                    else
                        System.out.println("Sorry! Product already added in the cart.");
  
            }
            else if(nextInput=='N' || nextInput=='n')
            {   
                System.out.println("Thank you for registering!");
                transaction.setTotalCost(calulateTotalPrice(transaction, inCart));
                System.out.println("Current Total Price of Cart : " + transaction.getTotalCost());
                flag = false;
            }
            else
                System.out.println("Enter a valid input!");
        }

        return inCart;
    }

    /** ------------- REMOVE PRODUCTS -------------
     * @description this method deletes products from the cart by calling method from class saleTransaction and 
     *              removing product from the cart.
     * @parameters  inCart
     * @returntype  int
     * @author      Itisha Singh
     */
    private int removeProductsFromCart(int inCart)
    {
        Scanner scan = new Scanner(System.in);
        int productNumber = 0;
        double totalPrice=0.0;
        boolean flag;
        transaction.viewCart(inCart);
        flag= true;
        while(flag)
        { 
            System.out.print("Enter Y to delete a product or N to exit : ");
            char nextInput = scan.next().charAt(0);
            if(nextInput=='Y' || nextInput=='y')
            {
                if(inCart!=0)
                {
                    System.out.println("Enter Product Number: ");
                    while(!scan.hasNextInt())
                    {
                        System.out.println("Invalid Input! Enter numeric value!");
                        scan.next();
                    }
                    productNumber = scan.nextInt();
                    while(productNumber > inCart || productNumber <=0)
                    {    
                    System.out.println("Enter a valid product number!");
                    while(!scan.hasNextInt())
                    {
                        System.out.println("Invalid Input! Enter numeric value!");
                        scan.next();
                    }
                    productNumber = scan.nextInt();
                }
                    transaction.removeFromCart(productNumber-1, inCart);
                    inCart = inCart-1;
                }
                else
                {
                    System.out.println(" Cart is already empty!");
                    flag = false;
                }
            }
            else if(nextInput=='n' || nextInput=='n')
            {  
                System.out.println(" Cart is Updated after Necessary Deletions...!");
                /**transaction.setTotalCost(calulateTotalPrice(transaction, inCart));
                System.out.println("Current Total Price of Cart : " + transaction.getTotalCost());*/
                flag = false;
            }
            else
                System.out.println("Enter a valid input!");
        }
        return inCart;
    }

    /** ------------- CHECKOUT PRODUCTS -------------
     * @description this method finalizez the sale. It updates the quantity on hand by substracting the minium quantity from it.
     * @parameters inCart, noOfItems, rand
     * @returntype  void
     * @author      Itisha Singh
     */
    private void checkoutCart(int inCart, int noOfItems, RandomNumberGenerator rand)
    {
        double totalCost = 0.0;
        int updatedQty = 0, count, innerloop;
        String name = "";
        System.out.println("***********************FINALIZING THE SALE****************");
        System.out.println("Your current Cart has . . .!");
        transaction.viewCart(inCart);
        int saleCode = rand.generateRandomNumber(1000,9999);

        if(inCart == 0 )
            System.out.println("Empty Cart Cant be checked out!");
        else
        {

            for(count=0; count < inCart; count++)
            {
                name = prodList.getListOfProducts()[count].getName();
            }
            count = 0 ; innerloop = 0;
            while(count < inCart)
            {
                while(innerloop < noOfItems)
                {
                    if((transaction.getItems()[count].getName()).equalsIgnoreCase(prodList.getListOfProducts()[innerloop].getName()))
                    {
                        updatedQty = prodList.getListOfProducts()[innerloop].getQtyOnHand() - prodList.getListOfProducts()[innerloop].getMinOrderQty();
                        prodList.getListOfProducts()[innerloop].setQtyOnHand(updatedQty);
                        break;
                    }
                    innerloop++;
                }
                count++;
            }
            System.out.println("\n\nTHE FINAL INVOICE");
            System.out.println("Sale Code :" + saleCode);
            System.out.println("Number of Products bought : " + inCart);
            transaction.setTotalCost(calulateTotalPrice(transaction, inCart));
            System.out.println("Total Price on billing is : " + transaction.getTotalCost());
        }
    }

    /** ------------- HELP -------------
     * @description this method just displays an elaborated description of all the options given to user.
     * @parameters  none
     * @returntype  void
     * @author      Itisha Singh
     */
    private void helpUser()
    {
        System.out.print('\u000C');
        System.out.println("********************************** Please Read Below! ********************************");
        System.out.println("1st Option : is for adding products to the inventory. If the inventory is empty you cannot add or remove anything from cart. and neither can you checkout. \n"+
            "You are not allowed to register more than 5 products in the inventory!\n\n"+
            "2nd Option : permits you to add items to the cart! only the products avaiable in the inventory can be added to cart. Also product name has to be unique.\n "+
            "You are not allowed to add more than 3 products in the inventory!\n\n"+
            "3rd Option : lets you remove any products you have added to the cart. and updates the shopping cart. \n"+
            "You cannot delete something that isn't already added in the cart. your cart needs items to be able to delete. \n\n "+
            "4th Option : displays all the products avaible in the inventory so you can choose from it to add in the cart. \n\n"+
            "5th Option : is to finalize the sale. It won't work if your cart it empty. Only products added in cart can be bought.\n"+
            "Once sale goes through. The amount of products in inventory gets updated.\n\n"+
            "6th Option : CURRENTLY CHOSEN OPTION..!\n\n"+
            "7th Option : choose this to exit the inventory system.\n");
        System.out.println("****************************** Glad We could Help! ************************************");
    }

    /** ------------- CALCULATE TOTAL PRICE -------------
     * @description this method calculates price of cart. 
     * @parameters  transaction, inCart
     * @returntype  double
     * @author      Itisha Singh
     */
    private double calulateTotalPrice(SaleTransaction transaction, int inCart)
    {
        double finalPrice = 0.0;
        for(int count=0; count < inCart; count++)
        {
            finalPrice = finalPrice + (transaction.getItems()[count].getPrice() *  transaction.getItems()[count].getMinOrderQty());
        }
        return finalPrice;
    }
}
